package com.example.miappnathy

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.miappnathy.adapter.ProductAdapter
import com.example.miappnathy.database.InventoryDbHelper
import com.example.miappnathy.model.Product
import com.google.android.material.card.MaterialCardView
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton
import com.google.android.material.snackbar.Snackbar
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var dbHelper: InventoryDbHelper
    private lateinit var productAdapter: ProductAdapter

    // Views
    private lateinit var tvSummaryUnits: TextView
    private lateinit var tvSummaryValue: TextView
    private lateinit var tvSummaryAlerts: TextView
    private lateinit var cardLowStockAlert: MaterialCardView
    private lateinit var etSearch: EditText
    private lateinit var chipGroupFilters: ChipGroup
    private lateinit var chipFilterAll: Chip
    private lateinit var chipFilterLowStock: Chip
    private lateinit var tvProductCount: TextView
    private lateinit var tvClearFilter: TextView
    private lateinit var rvProducts: RecyclerView
    private lateinit var layoutEmptyState: LinearLayout
    private lateinit var fabAddProduct: ExtendedFloatingActionButton

    // Filter states
    private var currentSearchQuery: String = ""
    private var currentCategoryFilter: String? = null
    private var isOnlyLowStock: Boolean = false

    private val formLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            loadDashboardAndProducts()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        dbHelper = InventoryDbHelper(this)
        dbHelper.seedDemoDataIfEmpty()

        initViews()
        setupRecyclerView()
        setupListeners()
        loadDashboardAndProducts()
    }

    override fun onResume() {
        super.onResume()
        loadDashboardAndProducts()
    }

    private fun initViews() {
        tvSummaryUnits = findViewById(R.id.tvSummaryUnits)
        tvSummaryValue = findViewById(R.id.tvSummaryValue)
        tvSummaryAlerts = findViewById(R.id.tvSummaryAlerts)
        cardLowStockAlert = findViewById(R.id.cardLowStockAlert)
        etSearch = findViewById(R.id.etSearch)
        chipGroupFilters = findViewById(R.id.chipGroupFilters)
        chipFilterAll = findViewById(R.id.chipFilterAll)
        chipFilterLowStock = findViewById(R.id.chipFilterLowStock)
        tvProductCount = findViewById(R.id.tvProductCount)
        tvClearFilter = findViewById(R.id.tvClearFilter)
        rvProducts = findViewById(R.id.rvProducts)
        layoutEmptyState = findViewById(R.id.layoutEmptyState)
        fabAddProduct = findViewById(R.id.fabAddProduct)
    }

    private fun setupRecyclerView() {
        productAdapter = ProductAdapter(
            products = emptyList(),
            onProductClick = { product ->
                openProductForm(product.id)
            },
            onProductLongClick = { product ->
                showProductOptionsDialog(product)
            },
            onStockChange = { product, newStock ->
                updateProductStock(product, newStock)
            }
        )

        rvProducts.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = productAdapter
            setHasFixedSize(false)
        }
    }

    private fun setupListeners() {
        // FAB to create new product
        fabAddProduct.setOnClickListener {
            openProductForm(null)
        }

        // Search live filter
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                currentSearchQuery = s?.toString()?.trim() ?: ""
                filterProducts()
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        // Chip Filters
        chipGroupFilters.setOnCheckedStateChangeListener { _, checkedIds ->
            when {
                checkedIds.contains(R.id.chipFilterLowStock) -> {
                    isOnlyLowStock = true
                    currentCategoryFilter = null
                }
                checkedIds.contains(R.id.chipFilterAll) -> {
                    isOnlyLowStock = false
                    currentCategoryFilter = null
                }
                else -> {
                    isOnlyLowStock = false
                    val checkedChip = checkedIds.firstOrNull()?.let { findViewById<Chip>(it) }
                    currentCategoryFilter = checkedChip?.tag as? String
                }
            }
            filterProducts()
        }

        // Quick low stock card shortcut
        cardLowStockAlert.setOnClickListener {
            chipFilterLowStock.isChecked = true
        }

        // Clear filter button
        tvClearFilter.setOnClickListener {
            etSearch.text.clear()
            chipFilterAll.isChecked = true
            currentSearchQuery = ""
            currentCategoryFilter = null
            isOnlyLowStock = false
            filterProducts()
        }

        // Empty state demo data loader
        findViewById<View>(R.id.btnSeedDemoData).setOnClickListener {
            dbHelper.seedDemoProducts()
            loadDashboardAndProducts()
            Snackbar.make(rvProducts, "Datos de prueba cargados correctamente", Snackbar.LENGTH_SHORT).show()
        }
    }

    private fun loadDashboardAndProducts() {
        // Summary KPIs
        val summary = dbHelper.getInventorySummary()
        tvSummaryUnits.text = "${summary.totalProducts} prods / ${summary.totalStockUnits} uds"
        tvSummaryValue.text = String.format(Locale.US, "$%.2f", summary.totalInventoryCost)
        tvSummaryAlerts.text = "${summary.lowStockCount} alertas"

        updateCategoryChips()
        filterProducts()
    }

    private fun updateCategoryChips() {
        val categories = dbHelper.getCategories()

        // Keep static chips (Todos, Stock Bajo) and remove previously added dynamic chips
        val childCount = chipGroupFilters.childCount
        for (i in childCount - 1 downTo 0) {
            val child = chipGroupFilters.getChildAt(i)
            if (child.id != R.id.chipFilterAll && child.id != R.id.chipFilterLowStock) {
                chipGroupFilters.removeViewAt(i)
            }
        }

        // Add dynamic category chips
        for (category in categories) {
            val chip = Chip(this).apply {
                text = category
                tag = category
                isCheckable = true
            }
            chipGroupFilters.addView(chip)
        }
    }

    private fun filterProducts() {
        val products = dbHelper.getAllProducts(
            query = currentSearchQuery,
            category = currentCategoryFilter,
            onlyLowStock = isOnlyLowStock
        )

        productAdapter.updateData(products)

        val hasActiveFilters = currentSearchQuery.isNotEmpty() || isOnlyLowStock || currentCategoryFilter != null
        tvClearFilter.visibility = if (hasActiveFilters) View.VISIBLE else View.GONE

        tvProductCount.text = when {
            products.isEmpty() && hasActiveFilters -> "Sin coincidencias"
            products.isEmpty() -> "0 productos"
            else -> "Mostrando ${products.size} producto${if (products.size > 1) "s" else ""}"
        }

        // Check if DB is completely empty for empty state
        val allProductsCount = dbHelper.getAllProducts().size
        if (allProductsCount == 0) {
            layoutEmptyState.visibility = View.VISIBLE
            rvProducts.visibility = View.GONE
        } else {
            layoutEmptyState.visibility = View.GONE
            rvProducts.visibility = View.VISIBLE
        }
    }

    private fun updateProductStock(product: Product, newStock: Int) {
        val success = dbHelper.updateStock(product.id, newStock)
        if (success) {
            loadDashboardAndProducts()
        }
    }

    private fun openProductForm(productId: Long?) {
        val intent = Intent(this, MainActivity2::class.java).apply {
            if (productId != null) {
                putExtra(MainActivity2.EXTRA_PRODUCT_ID, productId)
            }
        }
        formLauncher.launch(intent)
    }

    private fun showProductOptionsDialog(product: Product) {
        val options = arrayOf("Editar detalles", "Eliminar del inventario")
        AlertDialog.Builder(this)
            .setTitle(product.name)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> openProductForm(product.id)
                    1 -> confirmDeleteProduct(product)
                }
            }
            .show()
    }

    private fun confirmDeleteProduct(product: Product) {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.confirm_delete_title))
            .setMessage(getString(R.string.confirm_delete_msg, product.name))
            .setPositiveButton("Eliminar") { _, _ ->
                dbHelper.deleteProduct(product.id)
                loadDashboardAndProducts()
                Snackbar.make(rvProducts, getString(R.string.msg_product_deleted), Snackbar.LENGTH_SHORT).show()
            }
            .setNegativeButton(getString(R.string.btn_cancel), null)
            .show()
    }
}
