package com.example.miappnathy.database

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.miappnathy.model.InventorySummary
import com.example.miappnathy.model.Product

class InventoryDbHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        const val DATABASE_NAME = "inventory.db"
        const val DATABASE_VERSION = 1

        const val TABLE_PRODUCTS = "products"
        const val COLUMN_ID = "id"
        const val COLUMN_NAME = "name"
        const val COLUMN_SKU = "sku"
        const val COLUMN_CATEGORY = "category"
        const val COLUMN_STOCK = "stock"
        const val COLUMN_MIN_STOCK = "min_stock"
        const val COLUMN_PURCHASE_PRICE = "purchase_price"
        const val COLUMN_SALE_PRICE = "sale_price"
        const val COLUMN_DESCRIPTION = "description"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTableSql = """
            CREATE TABLE $TABLE_PRODUCTS (
                $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_NAME TEXT NOT NULL,
                $COLUMN_SKU TEXT NOT NULL UNIQUE,
                $COLUMN_CATEGORY TEXT NOT NULL,
                $COLUMN_STOCK INTEGER NOT NULL DEFAULT 0,
                $COLUMN_MIN_STOCK INTEGER NOT NULL DEFAULT 5,
                $COLUMN_PURCHASE_PRICE REAL NOT NULL DEFAULT 0.0,
                $COLUMN_SALE_PRICE REAL NOT NULL DEFAULT 0.0,
                $COLUMN_DESCRIPTION TEXT
            );
        """.trimIndent()
        db.execSQL(createTableSql)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_PRODUCTS")
        onCreate(db)
    }

    fun insertProduct(product: Product): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_NAME, product.name.trim())
            put(COLUMN_SKU, product.sku.trim().uppercase())
            put(COLUMN_CATEGORY, product.category.trim())
            put(COLUMN_STOCK, product.stock)
            put(COLUMN_MIN_STOCK, product.minStock)
            put(COLUMN_PURCHASE_PRICE, product.purchasePrice)
            put(COLUMN_SALE_PRICE, product.salePrice)
            put(COLUMN_DESCRIPTION, product.description.trim())
        }
        return db.insert(TABLE_PRODUCTS, null, values)
    }

    fun updateProduct(product: Product): Int {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_NAME, product.name.trim())
            put(COLUMN_SKU, product.sku.trim().uppercase())
            put(COLUMN_CATEGORY, product.category.trim())
            put(COLUMN_STOCK, product.stock)
            put(COLUMN_MIN_STOCK, product.minStock)
            put(COLUMN_PURCHASE_PRICE, product.purchasePrice)
            put(COLUMN_SALE_PRICE, product.salePrice)
            put(COLUMN_DESCRIPTION, product.description.trim())
        }
        return db.update(
            TABLE_PRODUCTS,
            values,
            "$COLUMN_ID = ?",
            arrayOf(product.id.toString())
        )
    }

    fun updateStock(id: Long, newStock: Int): Boolean {
        if (newStock < 0) return false
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_STOCK, newStock)
        }
        val affected = db.update(
            TABLE_PRODUCTS,
            values,
            "$COLUMN_ID = ?",
            arrayOf(id.toString())
        )
        return affected > 0
    }

    fun deleteProduct(id: Long): Int {
        val db = writableDatabase
        return db.delete(
            TABLE_PRODUCTS,
            "$COLUMN_ID = ?",
            arrayOf(id.toString())
        )
    }

    fun getProductById(id: Long): Product? {
        val db = readableDatabase
        val cursor = db.query(
            TABLE_PRODUCTS,
            null,
            "$COLUMN_ID = ?",
            arrayOf(id.toString()),
            null,
            null,
            null
        )
        return cursor.use {
            if (it.moveToFirst()) cursorToProduct(it) else null
        }
    }

    fun getAllProducts(
        query: String? = null,
        category: String? = null,
        onlyLowStock: Boolean = false
    ): List<Product> {
        val db = readableDatabase
        val productList = mutableListOf<Product>()

        val selectionParts = mutableListOf<String>()
        val selectionArgs = mutableListOf<String>()

        if (!query.isNullOrBlank()) {
            selectionParts.add("($COLUMN_NAME LIKE ? OR $COLUMN_SKU LIKE ?)")
            val wildcard = "%${query.trim()}%"
            selectionArgs.add(wildcard)
            selectionArgs.add(wildcard)
        }

        if (!category.isNullOrBlank() && category != "Todos") {
            selectionParts.add("$COLUMN_CATEGORY = ?")
            selectionArgs.add(category)
        }

        if (onlyLowStock) {
            selectionParts.add("$COLUMN_STOCK <= $COLUMN_MIN_STOCK")
        }

        val selection = if (selectionParts.isNotEmpty()) selectionParts.joinToString(" AND ") else null
        val args = if (selectionArgs.isNotEmpty()) selectionArgs.toTypedArray() else null

        val cursor = db.query(
            TABLE_PRODUCTS,
            null,
            selection,
            args,
            null,
            null,
            "$COLUMN_NAME ASC"
        )

        cursor.use {
            while (it.moveToNext()) {
                productList.add(cursorToProduct(it))
            }
        }

        return productList
    }

    fun getCategories(): List<String> {
        val db = readableDatabase
        val categories = mutableListOf<String>()
        val cursor = db.rawQuery(
            "SELECT DISTINCT $COLUMN_CATEGORY FROM $TABLE_PRODUCTS WHERE $COLUMN_CATEGORY IS NOT NULL AND $COLUMN_CATEGORY != '' ORDER BY $COLUMN_CATEGORY ASC",
            null
        )
        cursor.use {
            while (it.moveToNext()) {
                categories.add(it.getString(0))
            }
        }
        return categories
    }

    fun getInventorySummary(): InventorySummary {
        val db = readableDatabase
        var totalProducts = 0
        var totalUnits = 0
        var totalCost = 0.0
        var totalRevenue = 0.0
        var lowStockCount = 0

        val query = """
            SELECT 
                COUNT(*) as total_items,
                COALESCE(SUM($COLUMN_STOCK), 0) as total_units,
                COALESCE(SUM($COLUMN_STOCK * $COLUMN_PURCHASE_PRICE), 0.0) as total_cost,
                COALESCE(SUM($COLUMN_STOCK * $COLUMN_SALE_PRICE), 0.0) as total_revenue,
                SUM(CASE WHEN $COLUMN_STOCK <= $COLUMN_MIN_STOCK THEN 1 ELSE 0 END) as low_stock_items
            FROM $TABLE_PRODUCTS
        """.trimIndent()

        val cursor = db.rawQuery(query, null)
        cursor.use {
            if (it.moveToFirst()) {
                totalProducts = it.getInt(0)
                totalUnits = it.getInt(1)
                totalCost = it.getDouble(2)
                totalRevenue = it.getDouble(3)
                lowStockCount = it.getInt(4)
            }
        }

        return InventorySummary(
            totalProducts = totalProducts,
            totalStockUnits = totalUnits,
            totalInventoryCost = totalCost,
            totalEstimatedRevenue = totalRevenue,
            lowStockCount = lowStockCount
        )
    }

    fun seedDemoDataIfEmpty() {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT COUNT(*) FROM $TABLE_PRODUCTS", null)
        val count = cursor.use {
            if (it.moveToFirst()) it.getInt(0) else 0
        }

        if (count == 0) {
            seedDemoProducts()
        }
    }

    fun seedDemoProducts() {
        val samples = listOf(
            Product(
                name = "Café Espresso Arábica 500g",
                sku = "ALM-001",
                category = "Alimentos y Bebidas",
                stock = 24,
                minStock = 8,
                purchasePrice = 4.50,
                salePrice = 8.90,
                description = "Granos seleccionados tostado medio, origen Colombia."
            ),
            Product(
                name = "Auriculares Bluetooth Inalámbricos",
                sku = "TEC-102",
                category = "Tecnología",
                stock = 4,
                minStock = 6,
                purchasePrice = 12.00,
                salePrice = 24.99,
                description = "Bluetooth 5.3, cancelación de ruido pasiva y estuche de carga."
            ),
            Product(
                name = "Cuaderno Profesional A5 Pasta Dura",
                sku = "PAP-034",
                category = "Papelería",
                stock = 50,
                minStock = 15,
                purchasePrice = 1.80,
                salePrice = 4.50,
                description = "100 hojas rayadas de 90g con elástico de cierre."
            ),
            Product(
                name = "Camiseta de Algodón Orgánico (Talla L)",
                sku = "TEX-205",
                category = "Textil y Moda",
                stock = 2,
                minStock = 5,
                purchasePrice = 6.00,
                salePrice = 15.00,
                description = "100% algodón orgánico peinado, color azul marino."
            ),
            Product(
                name = "Detergente Multiusos Biodegradable 1L",
                sku = "HOG-310",
                category = "Hogar y Limpieza",
                stock = 0,
                minStock = 10,
                purchasePrice = 2.10,
                salePrice = 4.25,
                description = "Fórmula concentrada con aroma a cítricos."
            ),
            Product(
                name = "Cargador Rápido USB-C 30W",
                sku = "TEC-108",
                category = "Tecnología",
                stock = 15,
                minStock = 5,
                purchasePrice = 7.50,
                salePrice = 16.90,
                description = "Compatible con Power Delivery (PD 3.0) y Quick Charge."
            )
        )

        for (product in samples) {
            insertProduct(product)
        }
    }

    private fun cursorToProduct(cursor: Cursor): Product {
        return Product(
            id = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_ID)),
            name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME)),
            sku = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_SKU)),
            category = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CATEGORY)),
            stock = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_STOCK)),
            minStock = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_MIN_STOCK)),
            purchasePrice = cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_PURCHASE_PRICE)),
            salePrice = cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_SALE_PRICE)),
            description = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DESCRIPTION)) ?: ""
        )
    }
}
