package com.example.miappnathy.model

import java.io.Serializable

data class Product(
    val id: Long = 0,
    val name: String,
    val sku: String,
    val category: String,
    val stock: Int,
    val minStock: Int = 5,
    val purchasePrice: Double,
    val salePrice: Double,
    val description: String = ""
) : Serializable {

    val profitMargin: Double
        get() = salePrice - purchasePrice

    val profitMarginPercent: Double
        get() = if (purchasePrice > 0) ((salePrice - purchasePrice) / purchasePrice) * 100.0 else 0.0

    val isOutOfStock: Boolean
        get() = stock <= 0

    val isLowStock: Boolean
        get() = stock > 0 && stock <= minStock
}

data class InventorySummary(
    val totalProducts: Int,
    val totalStockUnits: Int,
    val totalInventoryCost: Double,
    val totalEstimatedRevenue: Double,
    val lowStockCount: Int
)
