package com.example.miappnathy

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.miappnathy.database.InventoryDbHelper
import com.example.miappnathy.model.Product
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import java.util.Locale

class MainActivity2 : AppCompatActivity() {

    companion object {
        const val EXTRA_PRODUCT_ID = "extra_product_id"
    }

    private lateinit var dbHelper: InventoryDbHelper
    private var editingProductId: Long? = null

    // Views
    private lateinit var toolbarProductForm: MaterialToolbar
    private lateinit var tilProductName: TextInputLayout
    private lateinit var etProductName: TextInputEditText
    private lateinit var tilProductSku: TextInputLayout
    private lateinit var etProductSku: TextInputEditText
    private lateinit var actvCategory: AutoCompleteTextView
    private lateinit var tilCurrentStock: TextInputLayout
    private lateinit var etCurrentStock: TextInputEditText
    private lateinit var tilMinStock: TextInputLayout
    private lateinit var etMinStock: TextInputEditText
    private lateinit var tilPurchasePrice: TextInputLayout
    private lateinit var etPurchasePrice: TextInputEditText
    private lateinit var tilSalePrice: TextInputLayout
    private lateinit var etSalePrice: TextInputEditText
    private lateinit var tvLiveProfitMargin: TextView
    private lateinit var etDescription: TextInputEditText
    private lateinit var btnSaveProduct: MaterialButton
    private lateinit var btnDeleteProduct: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main2)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        dbHelper = InventoryDbHelper(this)

        initViews()
        setupCategoryDropdown()
        setupPriceMarginWatcher()
        setupListeners()

        val productId = intent.getLongExtra(EXTRA_PRODUCT_ID, -1L)
        if (productId != -1L) {
            editingProductId = productId
            setupEditMode(productId)
        } else {
            setupCreateMode()
        }
    }

    private fun initViews() {
        toolbarProductForm = findViewById(R.id.toolbarProductForm)
        tilProductName = findViewById(R.id.tilProductName)
        etProductName = findViewById(R.id.etProductName)
        tilProductSku = findViewById(R.id.tilProductSku)
        etProductSku = findViewById(R.id.etProductSku)
        actvCategory = findViewById(R.id.actvCategory)
        tilCurrentStock = findViewById(R.id.tilCurrentStock)
        etCurrentStock = findViewById(R.id.etCurrentStock)
        tilMinStock = findViewById(R.id.tilMinStock)
        etMinStock = findViewById(R.id.etMinStock)
        tilPurchasePrice = findViewById(R.id.tilPurchasePrice)
        etPurchasePrice = findViewById(R.id.etPurchasePrice)
        tilSalePrice = findViewById(R.id.tilSalePrice)
        etSalePrice = findViewById(R.id.etSalePrice)
        tvLiveProfitMargin = findViewById(R.id.tvLiveProfitMargin)
        etDescription = findViewById(R.id.etDescription)
        btnSaveProduct = findViewById(R.id.btnSaveProduct)
        btnDeleteProduct = findViewById(R.id.btnDeleteProduct)
    }

    private fun setupCategoryDropdown() {
        val defaultCategories = mutableSetOf(
            "Alimentos y Bebidas",
            "Tecnología",
            "Papelería y Oficina",
            "Textil y Moda",
            "Hogar y Limpieza",
            "Ferretería y Herramientas",
            "Salud y Belleza",
            "General"
        )
        defaultCategories.addAll(dbHelper.getCategories())

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_dropdown_item_1line,
            defaultCategories.toList().sorted()
        )
        actvCategory.setAdapter(adapter)
    }

    private fun setupPriceMarginWatcher() {
        val watcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                updateProfitMarginPreview()
            }
            override fun afterTextChanged(s: Editable?) {}
        }

        etPurchasePrice.addTextChangedListener(watcher)
        etSalePrice.addTextChangedListener(watcher)
    }

    private fun updateProfitMarginPreview() {
        val cost = etPurchasePrice.text.toString().toDoubleOrNull() ?: 0.0
        val sale = etSalePrice.text.toString().toDoubleOrNull() ?: 0.0

        val margin = sale - cost
        val marginPercent = if (cost > 0) ((sale - cost) / cost) * 100.0 else 0.0
        val sign = if (margin >= 0) "+" else ""

        tvLiveProfitMargin.text = String.format(Locale.US, "%s$%.2f (%s%.0f%%)", sign, margin, sign, marginPercent)

        if (margin >= 0) {
            tvLiveProfitMargin.setTextColor(ContextCompat.getColor(this, R.color.status_green_text))
        } else {
            tvLiveProfitMargin.setTextColor(ContextCompat.getColor(this, R.color.status_red_text))
        }
    }

    private fun setupCreateMode() {
        toolbarProductForm.title = getString(R.string.title_new_product)
        btnDeleteProduct.visibility = View.GONE
        etMinStock.setText("5")
        actvCategory.setText("General", false)
    }

    private fun setupEditMode(productId: Long) {
        toolbarProductForm.title = getString(R.string.title_edit_product)
        btnDeleteProduct.visibility = View.VISIBLE

        val product = dbHelper.getProductById(productId)
        if (product == null) {
            Toast.makeText(this, "Producto no encontrado", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        etProductName.setText(product.name)
        etProductSku.setText(product.sku)
        actvCategory.setText(product.category, false)
        etCurrentStock.setText(product.stock.toString())
        etMinStock.setText(product.minStock.toString())
        etPurchasePrice.setText(String.format(Locale.US, "%.2f", product.purchasePrice))
        etSalePrice.setText(String.format(Locale.US, "%.2f", product.salePrice))
        etDescription.setText(product.description)
        updateProfitMarginPreview()
    }

    private fun setupListeners() {
        toolbarProductForm.setNavigationOnClickListener {
            finish()
        }

        btnSaveProduct.setOnClickListener {
            saveProduct()
        }

        btnDeleteProduct.setOnClickListener {
            confirmDelete()
        }
    }

    private fun saveProduct() {
        tilProductName.error = null
        tilProductSku.error = null
        tilCurrentStock.error = null
        tilPurchasePrice.error = null
        tilSalePrice.error = null

        val name = etProductName.text.toString().trim()
        val sku = etProductSku.text.toString().trim().uppercase()
        val category = actvCategory.text.toString().trim().ifEmpty { "General" }
        val stockStr = etCurrentStock.text.toString().trim()
        val minStockStr = etMinStock.text.toString().trim()
        val purchasePriceStr = etPurchasePrice.text.toString().trim()
        val salePriceStr = etSalePrice.text.toString().trim()
        val description = etDescription.text.toString().trim()

        // Validations
        var hasError = false
        if (name.isEmpty()) {
            tilProductName.error = getString(R.string.err_empty_name)
            hasError = true
        }

        if (sku.isEmpty()) {
            tilProductSku.error = getString(R.string.err_empty_sku)
            hasError = true
        }

        val stock = stockStr.toIntOrNull()
        if (stock == null || stock < 0) {
            tilCurrentStock.error = getString(R.string.err_invalid_stock)
            hasError = true
        }

        val minStock = minStockStr.toIntOrNull() ?: 5

        val purchasePrice = purchasePriceStr.toDoubleOrNull()
        if (purchasePrice == null || purchasePrice < 0) {
            tilPurchasePrice.error = getString(R.string.err_invalid_price)
            hasError = true
        }

        val salePrice = salePriceStr.toDoubleOrNull()
        if (salePrice == null || salePrice < 0) {
            tilSalePrice.error = getString(R.string.err_invalid_price)
            hasError = true
        }

        if (hasError) return

        val product = Product(
            id = editingProductId ?: 0L,
            name = name,
            sku = sku,
            category = category,
            stock = stock!!,
            minStock = minStock,
            purchasePrice = purchasePrice!!,
            salePrice = salePrice!!,
            description = description
        )

        val resultSuccess = if (editingProductId != null) {
            dbHelper.updateProduct(product) > 0
        } else {
            dbHelper.insertProduct(product) != -1L
        }

        if (resultSuccess) {
            Toast.makeText(this, getString(R.string.msg_product_saved), Toast.LENGTH_SHORT).show()
            setResult(RESULT_OK)
            finish()
        } else {
            Toast.makeText(this, "Error al guardar: verifique que el SKU sea único", Toast.LENGTH_LONG).show()
        }
    }

    private fun confirmDelete() {
        val productId = editingProductId ?: return
        val productName = etProductName.text.toString()

        AlertDialog.Builder(this)
            .setTitle(getString(R.string.confirm_delete_title))
            .setMessage(getString(R.string.confirm_delete_msg, productName))
            .setPositiveButton("Eliminar") { _, _ ->
                dbHelper.deleteProduct(productId)
                Toast.makeText(this, getString(R.string.msg_product_deleted), Toast.LENGTH_SHORT).show()
                setResult(RESULT_OK)
                finish()
            }
            .setNegativeButton(getString(R.string.btn_cancel), null)
            .show()
    }
}
