package com.example.miappnathy.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.miappnathy.R
import com.example.miappnathy.model.Product
import java.util.Locale

class ProductAdapter(
    private var products: List<Product>,
    private val onProductClick: (Product) -> Unit,
    private val onProductLongClick: (Product) -> Unit,
    private val onStockChange: (Product, Int) -> Unit
) : RecyclerView.Adapter<ProductAdapter.ProductViewHolder>() {

    class ProductViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvProductName: TextView = itemView.findViewById(R.id.tvProductName)
        val tvProductSku: TextView = itemView.findViewById(R.id.tvProductSku)
        val tvProductCategory: TextView = itemView.findViewById(R.id.tvProductCategory)
        val tvStockBadge: TextView = itemView.findViewById(R.id.tvStockBadge)
        val tvSalePrice: TextView = itemView.findViewById(R.id.tvSalePrice)
        val tvPurchasePrice: TextView = itemView.findViewById(R.id.tvPurchasePrice)
        val tvProfitMargin: TextView = itemView.findViewById(R.id.tvProfitMargin)
        val tvCurrentStockQuick: TextView = itemView.findViewById(R.id.tvCurrentStockQuick)
        val btnIncrementStock: ImageButton = itemView.findViewById(R.id.btnIncrementStock)
        val btnDecrementStock: ImageButton = itemView.findViewById(R.id.btnDecrementStock)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_product, parent, false)
        return ProductViewHolder(view)
    }

    override fun getItemCount(): Int = products.size

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        val product = products[position]
        val context = holder.itemView.context

        holder.tvProductName.text = product.name
        holder.tvProductSku.text = "SKU: ${product.sku}"
        holder.tvProductCategory.text = product.category
        holder.tvCurrentStockQuick.text = product.stock.toString()

        // Stock Badge Styling
        when {
            product.isOutOfStock -> {
                holder.tvStockBadge.text = "Agotado (0)"
                holder.tvStockBadge.setBackgroundResource(R.drawable.bg_badge_red)
                holder.tvStockBadge.setTextColor(ContextCompat.getColor(context, R.color.status_red_text))
            }
            product.isLowStock -> {
                holder.tvStockBadge.text = "Stock Bajo (${product.stock})"
                holder.tvStockBadge.setBackgroundResource(R.drawable.bg_badge_orange)
                holder.tvStockBadge.setTextColor(ContextCompat.getColor(context, R.color.status_orange_text))
            }
            else -> {
                holder.tvStockBadge.text = "${product.stock} unid."
                holder.tvStockBadge.setBackgroundResource(R.drawable.bg_badge_green)
                holder.tvStockBadge.setTextColor(ContextCompat.getColor(context, R.color.status_green_text))
            }
        }

        // Prices formatting
        holder.tvSalePrice.text = String.format(Locale.US, "$%.2f", product.salePrice)
        holder.tvPurchasePrice.text = String.format(Locale.US, "(Costo: $%.2f)", product.purchasePrice)

        val margin = product.profitMargin
        val marginPercent = product.profitMarginPercent
        val sign = if (margin >= 0) "+" else ""
        holder.tvProfitMargin.text = String.format(Locale.US, "Margen: %s$%.2f (%s%.0f%%)", sign, margin, sign, marginPercent)
        
        if (margin >= 0) {
            holder.tvProfitMargin.setTextColor(ContextCompat.getColor(context, R.color.status_green_text))
        } else {
            holder.tvProfitMargin.setTextColor(ContextCompat.getColor(context, R.color.status_red_text))
        }

        // Click listeners
        holder.itemView.setOnClickListener {
            onProductClick(product)
        }

        holder.itemView.setOnLongClickListener {
            onProductLongClick(product)
            true
        }

        holder.btnIncrementStock.setOnClickListener {
            onStockChange(product, product.stock + 1)
        }

        holder.btnDecrementStock.setOnClickListener {
            if (product.stock > 0) {
                onStockChange(product, product.stock - 1)
            }
        }
    }

    fun updateData(newProducts: List<Product>) {
        this.products = newProducts
        notifyDataSetChanged()
    }
}
